package com.game.rogueadventure;

public class Tile
{
	boolean wall = false;
	boolean invisible = false;
}
